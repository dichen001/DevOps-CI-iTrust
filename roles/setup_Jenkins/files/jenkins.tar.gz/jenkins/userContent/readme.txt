Files in this directory will be served under your http://server/jenkins/userContent/
